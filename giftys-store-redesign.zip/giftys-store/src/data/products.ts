/**
 * PRODUCTS
 * --------
 * NOTE: these products, prices and descriptions are SAMPLE entries.
 * Replace them with Gifty's real products (name, price, colours, photos).
 * Photos: put files in /public/images and list their paths in `images`, e.g. ["/images/tote-1.jpg"].
 */

export interface Product {
  id: string;
  name: string;
  price: number;
  oldPrice?: number;
  category: string;
  color: string;
  colors: string[];
  description: string;
  material: string;
  size: string;
  care: string;
  images: string[];
  stock: number;
  rating: number;
  reviews: number;
  isBestSeller: boolean;
  isNewArrival: boolean;
  slug: string;
}

export const products: Product[] = [
  {
    id: "1",
    name: "Aurelia Tote Bag",
    price: 45000,
    oldPrice: 55000,
    category: "Tote Bags",
    color: "Black",
    colors: ["Black", "Beige", "Brown"],
    description: "Elegant structured tote with gold hardware. Perfect for work and weekend. Spacious interior with multiple compartments.",
    material: "Premium faux leather with gold-tone metal accents",
    size: "38cm x 30cm x 15cm",
    care: "Wipe clean with damp cloth. Avoid prolonged exposure to direct sunlight.",
    images: [], // add photos like "/images/aurelia-1.jpg"
    stock: 12,
    rating: 4.8,
    reviews: 34,
    isBestSeller: true,
    isNewArrival: true,
    slug: "aurelia-tote-bag",
  },
  {
    id: "2",
    name: "Bella Shoulder Bag",
    price: 38500,
    category: "Shoulder Bags",
    color: "Tan",
    colors: ["Tan", "Black", "Burgundy"],
    description: "Soft shoulder bag with adjustable strap. Feminine silhouette that pairs with both casual and formal looks.",
    material: "Soft textured vegan leather",
    size: "28cm x 22cm x 10cm",
    care: "Spot clean only. Store in dust bag when not in use.",
    images: [], // add photos like "/images/aurelia-1.jpg"
    stock: 8,
    rating: 4.6,
    reviews: 21,
    isBestSeller: true,
    isNewArrival: false,
    slug: "bella-shoulder-bag",
  },
  {
    id: "3",
    name: "Naomi Crossbody Bag",
    price: 32000,
    oldPrice: 38000,
    category: "Crossbody Bags",
    color: "Gold",
    colors: ["Gold", "Silver", "Black"],
    description: "Compact crossbody with chain strap. Ideal for evenings out and hands-free days.",
    material: "Metallic finish vegan leather with chain strap",
    size: "22cm x 15cm x 7cm",
    care: "Wipe with soft dry cloth. Keep away from water.",
    images: [], // add photos like "/images/aurelia-1.jpg"
    stock: 15,
    rating: 4.9,
    reviews: 47,
    isBestSeller: true,
    isNewArrival: true,
    slug: "naomi-crossbody-bag",
  },
  {
    id: "4",
    name: "Zara Mini Clutch",
    price: 25000,
    category: "Clutches",
    color: "Ivory",
    colors: ["Ivory", "Black", "Red"],
    description: "Sleek mini clutch for special occasions. Magnetic closure and removable chain.",
    material: "Smooth faux leather with satin lining",
    size: "20cm x 12cm x 4cm",
    care: "Wipe clean. Store flat.",
    images: [], // add photos like "/images/aurelia-1.jpg"
    stock: 20,
    rating: 4.5,
    reviews: 18,
    isBestSeller: false,
    isNewArrival: true,
    slug: "zara-mini-clutch",
  },
  {
    id: "5",
    name: "Grace Leather Backpack",
    price: 52000,
    category: "Backpacks",
    color: "Brown",
    colors: ["Brown", "Black", "Olive"],
    description: "Stylish leather-look backpack that balances fashion and function. Perfect for the modern professional.",
    material: "High-quality PU leather with adjustable straps",
    size: "32cm x 40cm x 14cm",
    care: "Wipe with damp cloth. Condition occasionally.",
    images: [], // add photos like "/images/aurelia-1.jpg"
    stock: 6,
    rating: 4.7,
    reviews: 29,
    isBestSeller: true,
    isNewArrival: false,
    slug: "grace-leather-backpack",
  },
  {
    id: "6",
    name: "Ivory Chain Bag",
    price: 41000,
    category: "Shoulder Bags",
    color: "Ivory",
    colors: ["Ivory", "Black", "Gold"],
    description: "Statement chain bag in soft ivory. The perfect finishing touch for any outfit.",
    material: "Textured vegan leather with heavy chain strap",
    size: "25cm x 18cm x 8cm",
    care: "Spot clean. Avoid moisture.",
    images: [], // add photos like "/images/aurelia-1.jpg"
    stock: 9,
    rating: 4.8,
    reviews: 33,
    isBestSeller: true,
    isNewArrival: true,
    slug: "ivory-chain-bag",
  },
  {
    id: "7",
    name: "Lola Bucket Bag",
    price: 35500,
    category: "Shoulder Bags",
    color: "Beige",
    colors: ["Beige", "Black", "Camel"],
    description: "Trendy bucket bag with drawstring closure. Soft and structured at the same time.",
    material: "Soft grain faux leather",
    size: "26cm x 28cm x 16cm",
    care: "Wipe clean with soft cloth.",
    images: [], // add photos like "/images/aurelia-1.jpg"
    stock: 11,
    rating: 4.4,
    reviews: 15,
    isBestSeller: false,
    isNewArrival: true,
    slug: "lola-bucket-bag",
  },
  {
    id: "8",
    name: "Pearl Evening Clutch",
    price: 28000,
    category: "Clutches",
    color: "Pearl",
    colors: ["Pearl", "Black", "Champagne"],
    description: "Elegant evening clutch with pearl detailing. Timeless piece for weddings and formal events.",
    material: "Satin with pearl embellishments",
    size: "22cm x 12cm x 3cm",
    care: "Spot clean carefully. Store in box.",
    images: [], // add photos like "/images/aurelia-1.jpg"
    stock: 7,
    rating: 4.9,
    reviews: 41,
    isBestSeller: true,
    isNewArrival: false,
    slug: "pearl-evening-clutch",
  },
  {
    id: "9",
    name: "Sophia Satchel",
    price: 48000,
    oldPrice: 58000,
    category: "Shoulder Bags",
    color: "Black",
    colors: ["Black", "Brown", "Navy"],
    description: "Classic satchel with top handle and shoulder strap. Structured elegance for everyday luxury.",
    material: "Premium PU leather with gold hardware",
    size: "30cm x 24cm x 12cm",
    care: "Wipe with damp cloth. Avoid sharp objects.",
    images: [], // add photos like "/images/aurelia-1.jpg"
    stock: 5,
    rating: 4.7,
    reviews: 26,
    isBestSeller: true,
    isNewArrival: false,
    slug: "sophia-satchel",
  },
  {
    id: "10",
    name: "Maya Hobo Bag",
    price: 36000,
    category: "Shoulder Bags",
    color: "Camel",
    colors: ["Camel", "Black", "Grey"],
    description: "Soft hobo bag that drapes beautifully. Casual luxury for everyday wear.",
    material: "Soft slouchy vegan leather",
    size: "35cm x 28cm x 12cm",
    care: "Wipe clean. Stuff with paper when storing.",
    images: [], // add photos like "/images/aurelia-1.jpg"
    stock: 10,
    rating: 4.6,
    reviews: 19,
    isBestSeller: false,
    isNewArrival: true,
    slug: "maya-hobo-bag",
  },
  {
    id: "11",
    name: "Gold Wallet",
    price: 18500,
    category: "Wallets & Accessories",
    color: "Gold",
    colors: ["Gold", "Black", "Rose Gold"],
    description: "Compact gold wallet with multiple card slots and coin pocket. The perfect companion for your bag.",
    material: "Metallic vegan leather",
    size: "11cm x 9cm x 2cm",
    care: "Wipe with soft dry cloth.",
    images: [], // add photos like "/images/aurelia-1.jpg"
    stock: 25,
    rating: 4.5,
    reviews: 52,
    isBestSeller: true,
    isNewArrival: false,
    slug: "gold-wallet",
  },
  {
    id: "12",
    name: "Classic Black Handbag",
    price: 42000,
    category: "Tote Bags",
    color: "Black",
    colors: ["Black", "Brown"],
    description: "Timeless black handbag that goes with everything. Structured design with secure zip closure.",
    material: "Smooth premium faux leather",
    size: "34cm x 26cm x 13cm",
    care: "Wipe clean regularly. Use leather conditioner sparingly.",
    images: [], // add photos like "/images/aurelia-1.jpg"
    stock: 14,
    rating: 4.8,
    reviews: 38,
    isBestSeller: true,
    isNewArrival: false,
    slug: "classic-black-handbag",
  },
];

export const categories = [
  { name: "Tote Bags", slug: "tote-bags", image: "" },
  { name: "Shoulder Bags", slug: "shoulder-bags", image: "" },
  { name: "Crossbody Bags", slug: "crossbody-bags", image: "" },
  { name: "Clutches", slug: "clutches", image: "" },
  { name: "Backpacks", slug: "backpacks", image: "" },
  { name: "Wallets & Accessories", slug: "wallets-accessories", image: "" },
];

export function getProductBySlug(slug: string): Product | undefined {
  return products.find((p) => p.slug === slug);
}

export function getProductsByCategory(category: string): Product[] {
  return products.filter((p) => p.category.toLowerCase() === category.toLowerCase());
}

export function formatPrice(price: number): string {
  return `₦${price.toLocaleString("en-NG")}`;
}
