Put your photos here (hero.jpg, product photos, etc.).
Then add the file path to src/data/images.ts or src/data/products.ts, e.g. "/images/hero.jpg".
